package com.simplecam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var modeText: TextView
    private var provider: ProcessCameraProvider? = null
    private var ext: ExtensionsManager? = null
    private var capture: ImageCapture? = null
    private var front = false
    private var modeIdx = 0
    // Auto = phone ka best AI pipeline (HDR/Night vendor extension se), Standard = normal
    private val modes = listOf("PHOTO" to ExtensionMode.AUTO, "NIGHT" to ExtensionMode.NIGHT,
        "HDR" to ExtensionMode.HDR, "PORTRAIT" to ExtensionMode.FACE_RETOUCH)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        modeText = findViewById(R.id.mode)
        findViewById<android.view.View>(R.id.shutter).setOnClickListener { shoot() }
        findViewById<android.view.View>(R.id.flip).setOnClickListener { front = !front; bind() }
        modeText.setOnClickListener {
            modeIdx = (modeIdx + 1) % modes.size
            modeText.text = modes[modeIdx].first; bind()
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (r.firstOrNull() == PackageManager.PERMISSION_GRANTED) start()
    }

    private fun start() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
            ef.addListener({ ext = ef.get(); bind() }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bind() {
        val p = provider ?: return
        var sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val mode = modes[modeIdx].second
        // Agar phone us mode ko support karta hai to uska computational pipeline use hoga
        if (ext?.isExtensionAvailable(sel, mode) == true) sel = ext!!.getExtensionEnabledCameraSelector(sel, mode)
        val res = ResolutionSelector.Builder().setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY).build()
        val prev = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        capture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY) // speed nahi, quality
            .setResolutionSelector(res).setJpegQuality(98).build()
        p.unbindAll()
        val cam = p.bindToLifecycle(this, sel, prev, capture!!)
        // Tap to focus
        preview.setOnTouchListener { v, e ->
            if (e.action == android.view.MotionEvent.ACTION_UP) {
                val pt = preview.meteringPointFactory.createPoint(e.x, e.y)
                cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                v.performClick()
            }; true
        }
    }

    private fun shoot() {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/SimpleCam")
        }
        val out = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        capture?.takePicture(out, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show() }
            override fun onError(e: ImageCaptureException) { Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        })
    }
}
